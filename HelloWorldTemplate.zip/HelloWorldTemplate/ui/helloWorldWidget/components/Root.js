import { createComponent, mapToProps } from 'frint';

const Root = createComponent({
  render() {
    const { appName, assets: { url } } = this.props;

    return (
      <div>
        <h2>Hello World!</h2>
        <p>I am the <code>{appName}</code> Widget!</p>
        <p>
          This widget is created using <a href="https://github.com/Travix-International/frint" title="Travix International Front-end Framework">FrinT!</a>
        </p>
        <div>
          <img src={url("logo.png")} alt="Powered by Travix Intl." />
        </div>
      </div>
    );
  }
});

export default mapToProps({
  app: (app) => ({ appName: app.getOption('name') }),
  factories: {
    assets: 'assets',
  }  
})(Root);
