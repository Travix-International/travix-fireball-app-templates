import { createApp } from 'frint';

import Root from './components/Root';

export default createApp({
  component: Root,
  name: 'widget-helloWorld'
});