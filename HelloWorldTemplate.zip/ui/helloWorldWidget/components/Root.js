import { createComponent, mapToProps } from 'frint';

const Root = createComponent({
  addProductToCart() {
    const { shoppingCartService, appId } = this.props;

    alert(`Welcome to Fireball app development.
In order to add a product to the Shopping Cart, you have to
  1. Add your provider service URL to the app.manifest
  2. Call ShoppingCart.addItem() with the proper product id and parameters
  3. Remove this alert`);

    shoppingCartService.addItem({
      AppId: appId,
      Quantity: 1,
      ProductId: 'TODO: Fill in ProductID',
      ProductParameters: 'TODO: Fill in your custom product parameters'
    });
  },

  render() {
    const { appName } = this.props;

    return (
      <div>
        <h2>Fireball app</h2>
        <p>To do: Add description about the product.</p>
        <button onClick={this.addProductToCart} className="submit-button">Add to cart</button>
      </div>
    );
  }
});

export default mapToProps({
  app: (app) => ({
    appName: app.getOption('name'),
    appId: app.getOption('appId')
  }),
  services: {
    shoppingCartService: 'shoppingCart'
  }
})(Root);
