import { createComponent, mapToProps } from 'frint';

const Root = createComponent({
  render() {
    const { appName } = this.props;

    return (
      <div>
        <h2>Hello World!</h2>
        <p>I am the <code>{appName}</code> Widget!</p>
      </div>
    );
  }
});

export default mapToProps({
  app: (app) => ({ appName: app.getOption('name') })
})(Root);
