import { createApp } from 'kit';

import Root from '../components/Root';

export default createApp({
  name: '{APP_NAME}',

  component: Root,

  beforeMount() {
    console.log('{APP_NAME}: beforeMount');
  },

  afterMount() {
    console.log('{APP_NAME}: afterMount');
  },

  beforeUnmount() {
    console.log('{APP_NAME}: beforeUnmount');
  }
});
