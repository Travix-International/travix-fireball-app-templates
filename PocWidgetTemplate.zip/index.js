import App from './app';

const app = new App({
  appId: '{APP_NAME}App',
  assetsBasePath: '/pocAssets/'
});

app.setRegion('sidebar');

export default app;

// or window.app.registerWidget(helloWorldApp, 'sidebar');
