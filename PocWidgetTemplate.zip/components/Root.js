import { createComponent, mapToProps } from 'kit';

const Root = createComponent({
  afterMount() {
    console.log('{APP_NAME} component: afterMount');
  },

  beforeUnmount() {
    console.log('{APP_NAME} component: beforeUnmount');
  },

  render() {
    const { appName, region } = this.props;

    return (
      <div>
        <h2>Hello World!</h2>
        <p>I am the <code>{appName}</code> Widget!</p>

        <iframe src="https://www.facebook.com/plugins/share_button.php?href=https%3A%2F%2Ftravix.io%2F&layout=button_count&size=large&mobile_iframe=false&appId=244793202198860&width=83&height=28"
                width="83" height="28" style={{border:'none',overflow:'hidden'}} scrolling="no" frameborder="0" allowTransparency="true"></iframe>
      </div>
    );
  }
});

export default mapToProps({
  app: (app) => {
    return {
      appName: app.getOption('name'),
      region: app.getOption('region')
    }
  },
  shared: (sharedState) => {
    return {
    };
  }
})(Root);
