var webpack = require('webpack');
var config = require('../../config');

module.exports = {
  entry: __dirname + '/index.js',
  plugins: [],
  output: {
    path: config.buildDirectory,
    filename: 'widget-{APP_NAME}.js'
  },
  module: {
    loaders: [
      {
        test: /\.(js)$/,
        loaders: [
          'babel'
        ]
      }
    ]
  },
  externals: config.externals,
  resolve: {
    extensions: [
      '',
      '.js'
    ]
  }
};
